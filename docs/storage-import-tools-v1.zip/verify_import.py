from pathlib import Path
import json,subprocess,collections,urllib.parse
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs'
def baseline(name):return json.loads(subprocess.check_output(['git','-C',str(D.parent),'show','origin/main:docs/'+name]))
before=baseline('catalogue-index.json');after=json.loads((D/'catalogue-index.json').read_text());old={};new={}
for h in '0123456789abcdef':old.update(baseline('details-'+h+'.json'));new.update(json.loads((D/('details-'+h+'.json')).read_text()))
a={r['id']:r for r in after['records']};b={r['id']:r for r in before['records']};assert len(a)==len(after['records'])==len(new);assert set(old)<=set(new)
for id,d in old.items():
 assert new[id]['source_records'][:len(d['source_records'])]==d['source_records'],id
 assert a[id]['favorite']==b[id]['favorite'];assert a[id].get('verified')==b[id].get('verified');assert a[id].get('study')==b[id].get('study')
 assert set(b[id]['categories'])<=set(a[id]['categories'])
for id,d in new.items():
 assert d['id']==id;assert d['categories']==a[id]['categories'];assert set(d['categories'])<=set(after['categories'])
 for s in d['source_records']:
  for u in s.get('source_urls',[]):assert urllib.parse.urlsplit(u).scheme in ['http','https']
assert after['source_record_count']==sum(len(d['source_records'])for d in new.values());pending=json.loads((D/'storage-import-pending-identities.json').read_text());added=[s for d in new.values()for s in d['source_records']if s.get('collection')=='storage-sorting-20261019'];assert len(added)+len(pending['rows'])==156;assert len({s['row']for s in added}|{r['row']for r in pending['rows']})==156
assert sum(e['favorite']for e in after['records'])==sum(e['favorite']for e in before['records'])==42
out={'status':'PASS','master_rows_preserved':156,'imported_observations':len(added),'pending_identity_observations':len(pending['rows']),'old_entries':len(b),'new_total_entries':len(a),'favorites_preserved':42,'old_source_observations_preserved':before['source_record_count'],'native_verification_promotions':0};(R/'verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
