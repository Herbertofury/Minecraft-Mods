from pathlib import Path
import json,zipfile,xml.etree.ElementTree as E,re,urllib.parse,collections
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs';z=zipfile.ZipFile(R/'current-master.xlsx');ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};rel={x.get('Id'):x.get('Target')for x in E.fromstring(z.read('xl/worksheets/_rels/sheet2.xml.rels'))};links={x.get('ref'):rel.get(x.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'))for x in E.fromstring(z.read('xl/worksheets/sheet2.xml')).findall('s:hyperlinks/s:hyperlink',ns)}
def key(u):
 p=urllib.parse.urlsplit(u or '');return p.netloc.lower().removeprefix('www.')+p.path.rstrip('/') if p.scheme in ['https','http']else None
ix=json.loads((D/'catalogue-index.json').read_text());byurl=collections.defaultdict(set)
for e in ix['records']:
 if key(e.get('official')):byurl[key(e['official'])].add(e['id'])
for shard in D.glob('details-?.json'):
 for id,d in json.loads(shard.read_text()).items():
  for src in d.get('source_records',[]):
   for u in src.get('source_urls',[]):
    if key(u):byurl[key(u)].add(id)
rows=[]
for raw in json.loads((R/'workbook-rows.json').read_text())['Master Index']:
 number=int(re.search(r'\d+',next(iter(raw))).group());v={re.sub(r'\d+','',k):s for k,s in raw.items()}
 if number<=4 or not v.get('B'):continue
 u=links.get('Z'+str(number)) or (v.get('Z')if v.get('Z','').startswith('https://')else None);ids=sorted(byurl.get(key(u),set()));rows.append({'row':number,'name':v['B'],'project_url':u,'matched_ids':ids,'fields':v})
(R/'reconciliation-preview.json').write_text(json.dumps(rows,indent=2)+'\n');print('Rows',len(rows),'matched',sum(len(x['matched_ids'])==1 for x in rows),'ambiguous',sum(len(x['matched_ids'])>1 for x in rows),'new_or_unresolved',sum(not x['matched_ids']for x in rows));print(json.dumps([{'row':x['row'],'name':x['name'],'url':x['project_url']}for x in rows if not x['matched_ids']],indent=2))
