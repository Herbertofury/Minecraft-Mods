"""Conservative source-observation import. Never promotes imported claims to verification."""
from pathlib import Path
import json,hashlib,collections,urllib.parse,re,subprocess
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs';ix=json.loads((D/'catalogue-index.json').read_text());details={}
for p in D.glob('details-?.json'):details.update(json.loads(p.read_text()))
assert not any(s.get('collection')=='storage-sorting-20261019'for d in details.values()for s in d['source_records']),'Already imported; inspect before rerunning'
# Verify this import starts from the published data, preserving earlier unrelated edits.
for p in [D/'catalogue-index.json',*D.glob('details-?.json')]:assert subprocess.check_output(['git','-C',str(D.parent),'show','origin/main:docs/'+p.name])==p.read_bytes(),p.name
original_ids=set(details);original_sources=sum(len(d['source_records'])for d in details.values());records={e['id']:e for e in ix['records']};rows=json.loads((R/'reconciliation-preview.json').read_text());old={m['name']:m for m in json.loads((R/'storage_mods.json').read_text())['mods']}
def canonical(u):
 p=urllib.parse.urlsplit(u or '')
 if p.scheme not in ['https','http']:return None
 host=p.netloc.lower().removeprefix('www.');path=p.path.rstrip('/')
 if host=='curseforge.com':path=re.sub(r'/files/\d+.*$','',path)
 if host=='modrinth.com':path=re.sub(r'/version/[^/]+.*$','',path)
 return host+path
byurl={}
for id,d in details.items():
 for u in [d.get('official_project')]:
  k=canonical(u)
  if k:byurl.setdefault(k,set()).add(id)
# Same linked upstream repository checked on both hosting pages, 2026-10-19.
manual={'Sophisticated Storage':'775e3f8734c8410d','Storage Drawers':'f9fd892761c04bf2','Occultism':'3d45d2a8c9802050',"Tom's Simple Storage Mod":'a80c64ca4d493885','Ars Nouveau':'6d235f747de0b5ea','Create: Storage':'111454f45a25d670','Inventory Profiles Next':'ed89dcf55c7e575b','Shulker Box Tooltip':'a988ab4974505fdc','Inventory Essentials':'7702054706488b12','Mouse Tweaks':'a47ad4dd61b35cec','Applied Energistics 2':'1208f79b3d2c5638'}
byname=collections.defaultdict(list)
for e in ix['records']:byname[e['name'].casefold()].append(e['id'])
applied=[];pending=[];new_ids=[]
for row in rows:
 f=row['fields'];u=row['project_url'];origin='current master workbook hyperlink or literal URL'
 if not u and row['name']in old:u=old[row['name']].get('source_url');origin='older 2026-09-07 JSON project link; current workbook claims kept separately'
 k=canonical(u);ids=set(byurl.get(k,set()))if k else set()
 if row['name']in manual:ids={manual[row['name']]}
 if not k or len(ids)>1 or(not ids and row['name'].casefold()in byname):
  pending.append({**row,'reason':'Missing exact project route or unresolved same-name identity','candidate_ids':byname.get(row['name'].casefold(),[])});continue
 categories=['Storage and Logistics'];category=f.get('C','').lower()
 if any(t in category for t in ['inventory','search','sorting qol','crafting & storage qol','hotkey']):categories.append('Interface and Accessibility')
 if any(t in category for t in ['routing','logistics','rail','create']):categories.append('Engineering and Vehicles')
 if 'magic'in category:categories.append('Magic and Progression')
 if 'decorative'in category:categories.append('Building and Decoration')
 if 'performance'in category:categories.append('Performance and Stability')
 edition='Bedrock'if 'bedrock'in f.get('L','').lower()or '/marketplace/'in u else'Java'
 typ='data_pack'if '/datapack/'in u else'mod'
 if row['name']=='Create (Stock Logistics)':typ='feature'
 source={'collection':'storage-sorting-20261019','row':row['row'],'name':row['name'],'creator':'Not recorded in this source view','minecraft_versions':f.get('M'),'loader':f.get('L'),'role':f.get('C'),'reason':f.get('V')or f.get('U')or f.get('G'),'source_urls':[u],'dependencies_claim':f.get('AF'),'world_save_impact':f.get('AJ')or'Not separately established in this imported view','removal_update_notes':f.get('W'),'verification_claim':f.get('Y')or'Imported source observation; not independently retested','last_checked_claim':f.get('Y'),'notes':'\n'.join(x for x in [f.get('U'),f.get('W'),f.get('AE'),f.get('AI'),'Project URL provenance: '+origin]if x),'editorial_score':f.get('E')if re.fullmatch(r'\d+(\.\d+)?',f.get('E',''))else None,'extra_claims':f}
 if ids:
  id=next(iter(ids));d=details[id];e=records[id];d['source_records'].append(source);d['categories']=list(dict.fromkeys(d['categories']+categories));e['categories']=d['categories'];d['ecosystems']=list(dict.fromkeys(d['ecosystems']+[f.get('C','Storage research')]));e['ecosystems']=d['ecosystems']
  if not d.get('official_project'):
   d['official_project']='https://'+k;d['record_type']=typ;d['identity_review']='official project route resolved';e['official']=d['official_project'];e['type']=typ
 else:
  id=hashlib.sha256(k.encode()).hexdigest()[:16];assert id not in details
  d={'id':id,'key':k,'name':row['name'],'record_type':typ,'categories':categories,'edition':edition,'ecosystems':[f.get('C','Storage research')],'official_project':'https://'+k,'identity_review':'official project route resolved','source_records':[source],'evidence_level':'source-listed; not independently retested','direct_study':None,'favorite_in_source':False};e={'id':id,'name':d['name'],'type':typ,'categories':categories,'edition':edition,'ecosystems':d['ecosystems'],'favorite':False,'official':d['official_project'],'evidence':d['evidence_level'],'reason':source['reason'],'versions':source['minecraft_versions'],'study':None,'verified':None,'forever_world':False};details[id]=d;records[id]=e;new_ids.append(id)
 byurl.setdefault(k,set()).add(id);applied.append({'source_row':row['row'],'catalogue_id':id,'name':row['name']})
ix['records']=list(records.values());ix['source_record_count']=sum(len(d['source_records'])for d in details.values());ix['display_record_count']=len(records);ix['merged_source_row_count']=ix['source_record_count']-len(records);ix['resolved_project_identity_count']=sum(bool(e.get('official'))for e in records.values());ix['record_types']=dict(collections.Counter(e['type']for e in records.values()));ix['scope']+=' Storage and sorting master observations imported 2026-10-19; unresolved rows retained separately without guessed identity or fresh compatibility claims.'
ix['source_imports']=ix.get('source_imports',[])+[{'collection':'storage-sorting-20261019','workbook_sha256':hashlib.sha256((R/'current-master.xlsx').read_bytes()).hexdigest(),'master_rows':len(rows),'applied_rows':len(applied),'pending_identity_rows':len(pending)}]
assert set(details)==set(records)and original_ids<=set(details);assert ix['source_record_count']==original_sources+len(applied)
(D/'catalogue-index.json').write_text(json.dumps(ix,separators=(',',':'),ensure_ascii=False)+'\n')
for h in '0123456789abcdef':(D/('details-'+h+'.json')).write_text(json.dumps({k:v for k,v in details.items()if k.startswith(h)},separators=(',',':'),ensure_ascii=False)+'\n')
(D/'storage-import-pending-identities.json').write_text(json.dumps({'scope':'Preserved source observations awaiting exact project identity; no installation recommendation','rows':pending},indent=2)+'\n')
receipt={'source_rows':len(rows),'applied_rows':len(applied),'pending_rows':len(pending),'new_entries':len(new_ids),'before_entries':len(original_ids),'after_entries':len(records),'all_existing_ids_preserved':True,'source_record_count':ix['source_record_count'],'native_verification_promotions':0,'applied':applied};(R/'import-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k!='applied'}))
