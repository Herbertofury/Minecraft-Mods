from pathlib import Path
import json,subprocess,collections
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs';baseline='4be37f7';old={};new={};resolved={r['catalogue_id']:r['project_url']for r in json.loads((D/'musthave-identity-resolution.json').read_text())['resolved']}
for h in '0123456789abcdef':
 name='details-'+h+'.json';old.update(json.loads(subprocess.check_output(['git','-C',str(D.parent),'show',baseline+':docs/'+name])));new.update(json.loads((D/name).read_text()))
ix=json.loads((D/'catalogue-index.json').read_text());ids={e['id']for e in ix['records']};assert len(ids)==len(ix['records'])==2123 and set(old)<=ids==set(new)
for id,prior in old.items():
 d=new[id];assert d['source_records'][:len(prior['source_records'])]==prior['source_records'];assert all(d.get(k)==prior.get(k)for k in ['verified_release','direct_study','evidence_level']);assert not prior['favorite_in_source']or d['favorite_in_source'];assert d.get('official_project')==(resolved.get(id)or prior.get('official_project'))
assert sum(len(d['source_records'])for d in new.values())==2445;assert sum(e['favorite']for e in ix['records'])==279
source=[s for d in new.values()for s in d['source_records']if s.get('collection')=='musthave-conversion-20261019'];pending=json.loads((D/'musthave-pending-identities.json').read_text())['rows'];assert len(source)==286 and len(pending)==148
assert {s['row']for s in source}.isdisjoint({s['row']for s in pending});assert len({s['row']for s in source}|{s['row']for s in pending})==434
for d in new.values():
 assert d['categories']and all(c in ix['categories']for c in d['categories'])
 if d['id']not in old:assert d['evidence_level']=='source-listed; not independently retested'and not d.get('direct_study')
report={'status':'PASS','baseline_commit':baseline,'entries':2123,'attached_sources':2445,'catalogued_favorites':279,'old_entries_preserved':1935,'all_earlier_sources_and_favorites_preserved':True,'source_rows_partitioned_without_loss_or_overlap':434,'new_runtime_verification_claims':0};(D/'musthave-import-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
