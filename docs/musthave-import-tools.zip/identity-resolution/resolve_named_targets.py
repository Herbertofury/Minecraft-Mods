from pathlib import Path
import json,collections,hashlib,subprocess,copy
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs';ix=json.loads((D/'catalogue-index.json').read_text());details={}
for p in D.glob('details-?.json'):
 assert subprocess.check_output(['git','-C',str(D.parent),'show','origin/main:docs/'+p.name])==p.read_bytes();details.update(json.loads(p.read_text()))
entries={e['id']:e for e in ix['records']};pending=json.loads((D/'musthave-pending-identities.json').read_text());targets={'Terramity':'terramity','Malum':'malum','The Midnight':'the-midnight','Gateways to Eternity':'gateways-to-eternity','Oculus':'oculus','Create Jetpack':'create-jetpack'};resolved=[]
for row in list(pending['rows']):
 if row['name']not in targets:continue
 assert row['state']=='pending_same_name'and len(row['same_name_candidates'])==1
 id=row['same_name_candidates'][0];d=details[id];e=entries[id];assert d.get('official_project')is None
 url='https://www.curseforge.com/minecraft/mc-mods/'+targets[row['name']];assert url in row['urls'];f=row['fields'];fav=f.get('C')=='★'
 source={'collection':'musthave-conversion-20261019','row':row['row'],'source_id':f['A'],'name':f['B'],'creator':f.get('I'),'minecraft_versions':'1.20.1: '+f.get('L','Unknown')+'; 1.21.1: '+f.get('M','Unknown'),'loader':f.get('N'),'role':f.get('K'),'reason':f.get('D')or f.get('K'),'source_urls':row['urls'],'dependencies_claim':f.get('P'),'world_save_impact':'Not independently established in this import','removal_update_notes':f.get('Q'),'verification_claim':f.get('W'),'last_checked_claim':f.get('X'),'favorite_in_source':fav,'notes':'\n'.join(v for v in [f.get('D'),f.get('Q'),'Official project identity checked 2026-10-19; source release/support claims not freshly retested.']if v),'extra_claims':f}
 d['source_records'].append(source);d['official_project']=url;d['identity_review']='official project page identity checked 2026-10-19; no native qualification';d['record_type']='mod';d['favorite_in_source']=d.get('favorite_in_source',False)or fav;e['official']=url;e['type']='mod';e['favorite']=e.get('favorite',False)or fav
 resolved.append({'name':row['name'],'catalogue_id':id,'source_row':row['row'],'project_url':url,'evidence_scope':'Official project page title/identity; does not establish exact-release compatibility','checked_utc':'2026-10-19'});pending['rows'].remove(row)
assert len(resolved)==6
ix['records']=list(entries.values());ix['source_record_count']=sum(len(d['source_records'])for d in details.values());ix['merged_source_row_count']=ix['source_record_count']-len(entries);ix['resolved_project_identity_count']=sum(bool(e.get('official'))for e in entries.values());ix['record_types']=dict(collections.Counter(e['type']for e in entries.values()));ix['source_imports'].append({'collection':'musthave-target-identity-resolution-20261019','resolved_rows':6,'remaining_pending_rows':len(pending['rows'])})
(D/'catalogue-index.json').write_text(json.dumps(ix,separators=(',',':'),ensure_ascii=False)+'\n')
for h in '0123456789abcdef':(D/('details-'+h+'.json')).write_text(json.dumps({k:v for k,v in details.items()if k.startswith(h)},separators=(',',':'),ensure_ascii=False)+'\n')
(D/'musthave-pending-identities.json').write_text(json.dumps(pending,indent=2)+'\n');report={'resolved':resolved,'source_records':ix['source_record_count'],'entries':len(entries),'catalogued_favorites':sum(e['favorite']for e in entries.values()),'remaining_pending':len(pending['rows']),'native_verification_promotions':0};(D/'musthave-identity-resolution.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items()if k!='resolved'})
