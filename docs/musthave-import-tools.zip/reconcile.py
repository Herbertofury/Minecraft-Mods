import json,collections,re,urllib.parse,zipfile,xml.etree.ElementTree as E
from pathlib import Path
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs';data=json.loads((R/'workbook-rows.json').read_text())['All Mods'][3:];z=zipfile.ZipFile(R/'current-master.xlsx');n={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};rid='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id';rels={v.attrib['Id']:v.attrib['Target']for v in E.fromstring(z.read('xl/worksheets/_rels/sheet4.xml.rels'))};links={v.attrib['ref']:rels[v.attrib[rid]]for v in E.fromstring(z.read('xl/worksheets/sheet4.xml')).findall('s:hyperlinks/s:hyperlink',n)if rid in v.attrib};rows=[]
for row in data:rows.append({re.sub(r'\d','',k):links.get(k,v)for k,v in row.items()})
ds={}
for p in D.glob('details-?.json'):ds.update(json.loads(p.read_text()))
def canonical(u):
 p=urllib.parse.urlsplit(u or '');h=p.netloc.lower().removeprefix('www.');path=p.path.rstrip('/')
 if p.scheme not in ['https','http']:return None
 if h=='curseforge.com':path=re.sub(r'/files/\d+.*$','',path)
 if h=='modrinth.com':path=re.sub(r'/version/[^/]+.*$','',path)
 return h+path
byurl=collections.defaultdict(set);byname=collections.defaultdict(set)
for id,d in ds.items():
 k=canonical(d.get('official_project'))
 if k:byurl[k].add(id)
 byname[d['name'].casefold()].add(id)
preview=[]
for i,r in enumerate(rows,4):
 urls=[r[k]for k in ['R','S','T']if r.get(k,'').startswith('http')];keys=[canonical(u)for u in urls];ids=set().union(*(byurl[k]for k in keys));direct=[k for k in keys if any(t in k for t in ['curseforge.com/minecraft/mc-mods/','curseforge.com/minecraft/customization/','curseforge.com/minecraft/texture-packs/','modrinth.com/mod/','modrinth.com/resourcepack/','modrinth.com/datapack/','marketplace.minecraft.net/','minecraft.net/en-us/marketplace/'])];state='match'if len(ids)==1 else'conflict'if len(ids)>1 else'pending_same_name'if r['B'].casefold()in byname else'new_direct'if direct else'pending_route'
 preview.append({'row':i,'name':r['B'],'state':state,'matches':sorted(ids),'same_name_candidates':sorted(byname.get(r['B'].casefold(),[])),'direct_keys':direct,'urls':urls,'fields':r})
(R/'reconciliation-preview.json').write_text(json.dumps(preview,indent=2)+'\n');print(collections.Counter(x['state']for x in preview));print('Missing route samples',[(x['name'],x['urls'])for x in preview if x['state']=='pending_route'][:10])
