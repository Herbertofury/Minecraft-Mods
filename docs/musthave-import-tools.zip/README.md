# Starred collection consolidation

434 source rows partitioned into 280 attached observations and154 pending identities. Only exact existing official project routes or explicit source direct routes are imported. No same-name cross-host guesses. Favorites reflect source star flags; explicit Forever World flags remain unchanged. Never infer runtime compatibility from import or source scores. Read-only workbook parsing does not execute macros.
