from pathlib import Path
import zipfile,xml.etree.ElementTree as E,json,posixpath
R=Path(__file__).resolve().parent;z=zipfile.ZipFile(R/'current-master.xlsx');n={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};shared=[]
if 'xl/sharedStrings.xml'in z.namelist():shared=[''.join(x.itertext())for x in E.fromstring(z.read('xl/sharedStrings.xml'))]
rels={x.attrib['Id']:x.attrib['Target']for x in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))};out={}
for sh in E.fromstring(z.read('xl/workbook.xml')).find('s:sheets',n):
 target=rels[sh.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']];path=target.lstrip('/')if target.startswith('/')else posixpath.normpath('xl/'+target);root=E.fromstring(z.read(path));rows=[]
 for row in root.findall('s:sheetData/s:row',n):
  vals={}
  for c in row:
   v=c.find('s:v',n);val=v.text if v is not None else ''
   if c.get('t')=='s':val=shared[int(val)]if val else ''
   elif c.get('t')=='inlineStr':val=''.join(c.find('s:is',n).itertext())
   if val:vals[c.get('r')]=val
  if vals:rows.append(vals)
 out[sh.get('name')]=rows
(R/'workbook-rows.json').write_text(json.dumps(out,indent=2)+'\n');print({name:len(rows)for name,rows in out.items()})
