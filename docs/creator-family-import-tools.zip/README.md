# Official creator-project identity consolidation

Public unauthenticated Modrinth creator list, exact normalized titles, separate legacy/compatibility branches and two shared-source cross-host checks. Source stars and previous observations preserved; no native compatibility certification. No credentials or full project descriptions are required for the matching step.
