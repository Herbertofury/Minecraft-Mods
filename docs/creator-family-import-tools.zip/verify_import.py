from pathlib import Path
import json,subprocess
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs';baseline='5a65ba0';old={};new={}
for h in '0123456789abcdef':
 name='details-'+h+'.json';old.update(json.loads(subprocess.check_output(['git','-C',str(D.parent),'show',baseline+':docs/'+name])));new.update(json.loads((D/name).read_text()))
ix=json.loads((D/'catalogue-index.json').read_text());oldix=json.loads(subprocess.check_output(['git','-C',str(D.parent),'show',baseline+':docs/catalogue-index.json']));entries={r['id']:r for r in ix['records']};assert len(entries)==len(ix['records'])==2140 and set(old)<=set(entries)==set(new)
for id,d in old.items():
 n=new[id];assert n['source_records'][:len(d['source_records'])]==d['source_records'];assert all(n.get(k)==d.get(k)for k in ['official_project','evidence_level','direct_study','verified_release']);assert not d['favorite_in_source']or n['favorite_in_source']
for e in oldix['records']:assert entries[e['id']].get('forever_world')==e.get('forever_world')
assert sum(len(d['source_records'])for d in new.values())==2464;assert sum(e['favorite']for e in entries.values())==298
source=[s for d in new.values()for s in d['source_records']if s.get('collection')=='musthave-conversion-20261019'];pending=json.loads((D/'musthave-pending-identities.json').read_text())['rows'];assert len(source)==305 and len(pending)==129;assert len({s['row']for s in source}|{s['row']for s in pending})==434 and not({s['row']for s in source}&{s['row']for s in pending})
report={'status':'PASS','baseline_commit':baseline,'entries':2140,'source_records':2464,'catalogued_favorites':298,'new_entries':17,'resolved_rows':19,'remaining_pending_rows':129,'all_prior_source_observations_preserved':True,'forever_world_flags_unchanged':True,'native_verification_promotions':0};(D/'creator-family-data-tests.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
