# Final Java identity questions in the starred source collection

Six source observations resolved, five new entries. Historical source fields preserved. Resource-pack/datapack identity and the localization pack's version limitation are explicit. Native testing is not inferred. Remaining 55 source rows are Bedrock Marketplace targets. Other source collections remain in progress.
