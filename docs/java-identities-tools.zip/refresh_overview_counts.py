from pathlib import Path
import json,collections,re
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs';ix=json.loads((D/'catalogue-index.json').read_text());counts=collections.Counter(c for e in ix['records']for c in e['categories']);favorites=sum(e['favorite']for e in ix['records']);pending=len(json.loads((D/'musthave-pending-identities.json').read_text())['rows']);checks=[]
for p in [D.parent/'README.md',D/'Home.md',D/'Minecraft-Mods.md']:
 s=p.read_text()
 for cat,n in counts.items():
  pattern=r'(- \*\*\['+re.escape(cat)+r'\]\([^\n]+?\)\*\* — )\d+( project/feature/target entries; overlapping categories\.)'
  s,num=re.subn(pattern,lambda m:m[1]+str(n)+m[2],s);assert num==1,(p,cat,num);checks.append({'page':p.name,'category':cat,'count':n})
 s=s.split('## Current import coverage')[0]+f'''## Current import coverage

**{len(ix['records']):,} research entries · {ix['source_record_count']:,} attached source observations · {favorites:,} catalogued favorites.** {ix['merged_source_row_count']:,} repeated source observations are consolidated without dropping their notes. Entries include mods, resource packs, tools, targets and discovery routes; these are not counts of tested compatible mods.

The broad recommendations, gun research, creature variety, storage/sorting and starred/conversion collections are being brought together. Remaining HTML, document collections and unique source tabs still need reconciliation. Source files remain intact. Imported source stars and version claims remain distinct from explicit Forever World targets, freshly checked releases and native gameplay tests.

**{pending} starred/conversion source rows still need exact project identities.** Storage identity questions are tracked separately. [Unresolved starred rows](https://github.com/Herbertofury/Minecraft-Mods/blob/main/docs/musthave-pending-identities.json) · [Unresolved storage rows](https://github.com/Herbertofury/Minecraft-Mods/blob/main/docs/storage-import-pending-identities.json).

### Import evidence and preservation checks

- [Storage master import](https://github.com/Herbertofury/Minecraft-Mods/blob/main/docs/storage-import-receipt.json) and [companion research notes](https://github.com/Herbertofury/Minecraft-Mods/blob/main/docs/storage-companion-import-receipt.json).
- [Starred/conversion collection import](https://github.com/Herbertofury/Minecraft-Mods/blob/main/docs/musthave-import-receipt.json) and [six direct target identities](https://github.com/Herbertofury/Minecraft-Mods/blob/main/docs/musthave-identity-resolution.json).
- [Nineteen Let’s Do identities](https://github.com/Herbertofury/Minecraft-Mods/blob/main/docs/creator-family-data-tests.json), with legacy and compatibility branches kept separate.
- [Eighteen Relics/Octo identities](https://github.com/Herbertofury/Minecraft-Mods/blob/main/docs/relics-family-data-tests.json), categorized by described purpose.
- [Thirty-four Simply, Kaleidoscope, RPG Series and VR identities](https://github.com/Herbertofury/Minecraft-Mods/blob/main/docs/multifamily-data-tests.json): 27 new entries and seven cross-host matches using shared official repositories. Refabricated projects remain distinct; datapacks and resource packs retain their own types.

Sixteen further source rows are connected to official creature, decoration, physics, animation and spell-integration projects. [Identity and preservation tests](https://github.com/Herbertofury/Minecraft-Mods/blob/main/docs/remaining-identities-data-tests.json). The two joosh Clockwork source rows share one catalogue entry and remain distinct from unrelated Clockwork projects.

The last six Java-oriented identity questions in this starred source collection are resolved. [Evidence](https://github.com/Herbertofury/Minecraft-Mods/blob/main/docs/java-identities-data-tests.json). Remaining unresolved rows are 55 explicitly labeled Bedrock Marketplace research/conversion targets. This does not mean every separate source collection or release is verified.

Every pass preserves earlier source observations, favorites and explicit compatibility-target flags. Identity resolution does not certify a particular Minecraft build or native compatibility.
'''
 p.write_text(s)
(R/'overview-count-tests.json').write_text(json.dumps({'status':'PASS','checked_category_lines':len(checks),'entries':len(ix['records']),'sources':ix['source_record_count'],'favorites':favorites,'pending_starred_rows':pending,'checks':checks},indent=2)+'\n');print('39 overview category counts synchronized and checked')
