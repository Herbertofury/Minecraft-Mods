from pathlib import Path
import json,collections
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs';p=D/'catalogue-index.json';ix=json.loads(p.read_text());changes=[];aliases={'resource pack':'resource_pack','data pack':'data_pack'}
for e in ix['records']:
 if e['type']in aliases:
  changes.append({'id':e['id'],'name':e['name'],'before':e['type'],'after':aliases[e['type']]});e['type']=aliases[e['type']]
assert len(changes)==9,len(changes)
ix['record_types']=dict(collections.Counter(e['type']for e in ix['records']));p.write_text(json.dumps(ix,separators=(',',':'),ensure_ascii=False)+'\n')
for p in D.glob('details-?.json'):
 ds=json.loads(p.read_text());changed=False
 for d in ds.values():
  if d['record_type']in aliases:d['record_type']=aliases[d['record_type']];changed=True
 if changed:p.write_text(json.dumps(ds,separators=(',',':'),ensure_ascii=False)+'\n')
(R/'type-alias-fix.json').write_text(json.dumps({'scope':'Canonical entry-type IDs only; source observations and counts unchanged','changes':changes},indent=2)+'\n')
p=D/'index.html';p.write_text(p.read_text().replace('v=multifamily-identities-20261019','v=canonical-types-20261019'))
p=R/'import_verified_family.py';p.write_text(p.read_text().replace("typ='resource pack'","typ='resource_pack'").replace("else'data pack'","else'data_pack'"))
print('Normalized nine type IDs; no project, source or favorite removed')
