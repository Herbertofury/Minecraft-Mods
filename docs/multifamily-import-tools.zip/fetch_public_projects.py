from pathlib import Path
import urllib.request,json,hashlib,concurrent.futures
R=Path(__file__).resolve().parent
AUTHORS=['Sweenus','YSBB','BmtUltra','cyber','ZsoltMolnarrr']
def fetch(author):
 url='https://api.modrinth.com/v2/user/'+author+'/projects';req=urllib.request.Request(url,headers={'User-Agent':'Herbertofury/Minecraft-Mods-research/1.0 (https://github.com/Herbertofury/Minecraft-Mods)'})
 with urllib.request.urlopen(req,timeout=45)as response:raw=response.read(10000000)
 assert len(raw)<10000000
 safe=[{k:p.get(k)for k in ['id','slug','title','project_type','source_url','status','team','description','categories','additional_categories']}for p in json.loads(raw)]
 (R/(author+'-projects.json')).write_text(json.dumps({'url':url,'checked_utc':'2026-10-19','response_sha256':hashlib.sha256(raw).hexdigest(),'scope':'Public creator-project identity; no exact-release or native certification','projects':safe},indent=2)+'\n');return(author,len(safe))
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:
 for result in ex.map(fetch,AUTHORS):print(result,flush=True)
