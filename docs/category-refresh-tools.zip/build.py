from pathlib import Path
import json,re,urllib.parse,collections,subprocess,hashlib
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs';ix=json.loads((D/'catalogue-index.json').read_text());report=[];(R/'before').mkdir(exist_ok=True)
def esc(x):return str(x or'').replace('|','\\|').replace('[','\\[').replace(']','\\]').replace('\n',' ')
for cat in ix['categories']:
 if cat=='Storage and Logistics':continue
 name=cat.replace(' ','-')+'.md';p=D/name;old=p.read_text();assert subprocess.check_output(['git','-C',str(D.parent),'show','origin/main:docs/'+name])==p.read_bytes(),name
 original_prefix=old.split('<details>',1)[0];remainder=old[len(original_prefix):];prefix=re.sub(r'\*\*\d+ entries in this purpose category\.\*\* Refreshed from the consolidated index on 2026-10-19\. Stars include preserved source preferences; they do not certify compatibility\. Entries may appear in several relevant categories\.\s*','',original_prefix);assert not re.sub(r'<details>.*?</details>','',remainder,flags=re.S).strip(),'Unexpected custom text; preserve manually: '+name
 (R/'before'/name).write_text(old);rows=[e for e in ix['records']if cat in e['categories']];lines=[prefix.rstrip(),'','**'+str(len(rows))+' entries in this purpose category.** Refreshed from the consolidated index on 2026-10-19. Stars include preserved source preferences; they do not certify compatibility. Entries may appear in several relevant categories.',''];seen=[]
 for typ in sorted({e['type']for e in rows}):
  group=sorted((e for e in rows if e['type']==typ),key=lambda e:e['name'].casefold());lines+=['<details>',f'<summary><strong>{esc(typ.replace("_"," ").title())} · {len(group)}</strong></summary>','','| Project / target | Purpose | Evidence |','|---|---|---|']
  for e in group:
   id=e['id'];seen.append(id);url=e.get('official')or'https://herbertofury.github.io/Minecraft-Mods/?id='+id;title=('★ 'if e['favorite']else'')+'['+esc(e['name'])+']('+url+')';ev='[Actual-file study]('+e['study']+')'if e.get('study')else'Official release checked; native testing open'if e.get('verified')else'Target; native testing open'if typ=='compatibility_target'else'Discovery route; not an installable release'if typ=='discovery'else'Imported; check exact build';lines.append('| '+title+' | '+esc((e.get('reason')or'Purpose in detail record')[:180])+' | '+ev+' · [details](https://herbertofury.github.io/Minecraft-Mods/?id='+id+') |')
  lines+=['','</details>','']
 assert len(seen)==len(set(seen))==len(rows)
 text='\n'.join(lines)+'\n';p.write_text(text);report.append({'page':name,'category':cat,'entries':len(rows),'unique_detail_links':len(seen),'previous_sha256':hashlib.sha256(old.encode()).hexdigest(),'updated_sha256':hashlib.sha256(text.encode()).hexdigest()})
(R/'receipt.json').write_text(json.dumps({'scope':'Category navigation refresh only; source claims and data unchanged','pages':report,'native_verification_promotions':0},indent=2)+'\n');print([(r['category'],r['entries'])for r in report])
