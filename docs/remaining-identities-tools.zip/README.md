# Primary identity reconciliation

16 preserved source observations, 11 new entries. Exact official routes and project identities are distinct from native compatibility. Two joosh Clockwork observations share one entry. Source records and all previous verification levels remain preserved.
