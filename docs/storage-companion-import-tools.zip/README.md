# Companion observation consolidation

Read-only source extraction followed by matching to the already resolved master-import IDs. No new project identities, verification claims, favorites or display records are introduced. The script requires the exact published baseline and refuses dirty shards. Original notes are preserved; view-specific claims are labeled historical. Receipt separates unresolved identity observations.
