"""Attach unique source-view observations to already resolved master rows, without new identities or verification claims."""
from pathlib import Path
import json,subprocess,copy,hashlib,collections
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs';rows=json.loads((R/'companion-distinct-fields.json').read_text());receipts=json.loads((R/'import-receipt.json').read_text())['applied'];byname={r['name']:r for r in receipts};details={};before={}
for p in D.glob('details-?.json'):
 assert subprocess.check_output(['git','-C',str(D.parent),'show','origin/main:docs/'+p.name])==p.read_bytes(),p.name
 before[p.name]=p.read_bytes();details.update(json.loads(p.read_text()))
original=copy.deepcopy(details);pending=[];attached=[]
for row in rows:
 match=byname.get(row['name'])
 if not match:pending.append(row);continue
 d=details[match['catalogue_id']];source=next(s for s in d['source_records']if s.get('collection')=='storage-sorting-20261019'and s.get('row')==match['source_row']);assert not source.get('companion_notes_imported'),'Already applied'
 source.setdefault('companion_observations',[]).append({'sheet':row['sheet'],'row':row['row'],'fields':row['distinct_fields'],'status':'Historical source claim; not independently retested'})
 attached.append({'catalogue_id':d['id'],'sheet':row['sheet'],'row':row['row']})
for d in details.values():
 for s in d['source_records']:
  if not s.get('companion_observations'):continue
  unique=collections.OrderedDict()
  for r in s['companion_observations']:
   for k,v in r['fields'].items():unique.setdefault((k,v),[]).append(r['sheet']+':'+str(r['row']))
  s['notes']+='\nAdditional historical companion observations (not newly verified):\n'+'\n'.join(k+': '+v+' [source views: '+', '.join(loc)+']'for (k,v),loc in unique.items());s['companion_notes_imported']=True
# Nothing outside the matching source observation changes.
for id,d in details.items():
 old=original[id];assert {k:v for k,v in d.items()if k!='source_records'}=={k:v for k,v in old.items()if k!='source_records'}
 assert len(d['source_records'])==len(old['source_records'])
 for new,prior in zip(d['source_records'],old['source_records']):
  if new!=prior:assert new.get('collection')=='storage-sorting-20261019'and {k:v for k,v in new.items()if k not in ['notes','companion_observations','companion_notes_imported']}=={k:v for k,v in prior.items()if k!='notes'}
changed=[]
for h in '0123456789abcdef':
 p=D/('details-'+h+'.json');data=json.dumps({k:v for k,v in details.items()if k.startswith(h)},separators=(',',':'),ensure_ascii=False)+'\n'
 if data.encode()!=before[p.name]:p.write_text(data);changed.append(p.name)
report={'source_companion_rows':len(rows),'attached_view_observations':len(attached),'pending_identity_rows':len(pending),'unique_catalogue_entries_enriched':len(set(r['catalogue_id']for r in attached)),'display_entries_unchanged':len(details),'source_record_count_unchanged':sum(len(d['source_records'])for d in details.values()),'favorite_count_unchanged':sum(d.get('favorite_in_source',False)for d in details.values()),'native_verification_promotions':0,'changed_shards':changed,'attached':attached,'pending':pending}
(D/'storage-companion-import-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ['attached','pending']},indent=2))
