from pathlib import Path
import json,hashlib,collections,re,subprocess,copy
R=Path(__file__).resolve().parent;D=R.parents[1]/'minecraft-mods-repo/docs';ix=json.loads((D/'catalogue-index.json').read_text());details={}
for p in D.glob('details-?.json'):
 assert subprocess.check_output(['git','-C',str(D.parent),'show','origin/main:docs/'+p.name])==p.read_bytes(),p.name;details.update(json.loads(p.read_text()))
old=copy.deepcopy(details);entries={e['id']:e for e in ix['records']};pending=json.loads((D/'musthave-pending-identities.json').read_text());matches=json.loads((R/'match-evidence.json').read_text())['matches'];byrow={r['row']:r for r in pending['rows']};known={};applied=[];newids=[]
categories_by_slug={
'rac-compat':['Magic and Progression','Creatures and Companions'],
'ram-compat':['Magic and Progression','Creatures and Companions'],
'shatterbyte-lib':['Tools and Development'],
'notenoughrecipebook':['Interface and Accessibility','Performance and Stability'],
'immersive-ui':['Interface and Accessibility','Visuals and Resource Packs'],
'relics-mod':['Magic and Progression'],
'perception':['Visuals and Resource Packs'],
'reliquified-artifacts':['Magic and Progression'],
'curios-continuation':['Tools and Development'],
'cardiac':['Farming and Survival','Weapons and Combat'],
'clavis':['Storage and Logistics','Worlds and Exploration'],
'reliquified-ars-nouveau':['Magic and Progression'],
'reliquified-l-ender-s-cataclysm':['Magic and Progression','Weapons and Combat'],
'reliquified-twilight-forest':['Magic and Progression','Worlds and Exploration'],
're-animal':['Creatures and Companions'],
'reliquified-irons-spells-n-spellbooks':['Magic and Progression'],
'yagm':['Storage and Logistics','Farming and Survival','Creatures and Companions'],
'stellara':['Visuals and Resource Packs']}
for match in matches:
 row=byrow[match['source_row']];f=row['fields'];p=match['project'];assert p['project_type']=='mod';key='modrinth.com/mod/'+p['slug'];url='https://'+key;id=known.get(p['slug'])or hashlib.sha256(key.encode()).hexdigest()[:16];cats=categories_by_slug[p['slug']];fav=f.get('C')=='★';typ='library'if'library'in p['categories']else'mod'
 identity={'platform':'Modrinth','id':p['id'],'slug':p['slug'],'creator_projects_endpoint':'https://api.modrinth.com/v2/user/SSKirillSS/projects','source_repository':p['source_url'],'checked_utc':'2026-10-19','scope':'Project identity only; no exact release or native compatibility certification'}
 source={'collection':'musthave-conversion-20261019','row':row['row'],'source_id':f['A'],'name':f['B'],'creator':f.get('I'),'minecraft_versions':'1.20.1: '+f.get('L','Unknown')+'; 1.21.1: '+f.get('M','Unknown'),'loader':f.get('N'),'role':p['description'],'reason':p['description'],'source_urls':[u for u in [url,p['source_url']]if u],'dependencies_claim':f.get('P'),'world_save_impact':'Not independently established by this identity study','removal_update_notes':f.get('Q'),'verification_claim':f.get('W'),'last_checked_claim':f.get('X'),'favorite_in_source':fav,'notes':'\n'.join(v for v in [f.get('D'),f.get('Q'),'Project identity resolved from official public creator list; historical version/dependency claims remain untested.']if v),'extra_claims':f,'resolved_identity':identity}
 if id in known.values():
  d=details[id];e=entries[id];d['source_records'].append(source);d['verified_project_identities']=d.get('verified_project_identities',[])+[identity];d['favorite_in_source']=d.get('favorite_in_source',False)or fav;e['favorite']=e.get('favorite',False)or fav;d['categories']=list(dict.fromkeys(d['categories']+cats));e['categories']=d['categories']
 else:
  assert id not in details and not any((d.get('official_project')or'').rstrip('/')==url for d in details.values())
  d={'id':id,'key':key,'name':p['title'],'record_type':typ,'categories':cats,'edition':'Java','ecosystems':[f['H']],'official_project':url,'identity_review':'official public creator-project identity checked 2026-10-19','source_records':[source],'evidence_level':'source-listed; not independently retested','direct_study':None,'favorite_in_source':fav,'verified_project_identities':[identity]};e={'id':id,'name':p['title'],'type':typ,'categories':cats,'edition':'Java','ecosystems':d['ecosystems'],'favorite':fav,'official':url,'evidence':d['evidence_level'],'reason':p['description'],'versions':source['minecraft_versions'],'study':None,'verified':None,'forever_world':False};details[id]=d;entries[id]=e;newids.append(id)
 applied.append({'source_row':row['row'],'catalogue_id':id,'project_id':p['id'],'name':p['title'],'new_entry':id in newids});pending['rows'].remove(row)
for id,prior in old.items():
 assert details[id]['source_records'][:len(prior['source_records'])]==prior['source_records'];assert not prior['favorite_in_source']or details[id]['favorite_in_source'];assert all(details[id].get(k)==prior.get(k)for k in ['direct_study','evidence_level','official_project'])
ix['records']=list(entries.values());ix['source_record_count']=sum(len(d['source_records'])for d in details.values());ix['display_record_count']=len(entries);ix['merged_source_row_count']=ix['source_record_count']-len(entries);ix['resolved_project_identity_count']=sum(bool(e.get('official'))for e in entries.values());ix['record_types']=dict(collections.Counter(e['type']for e in entries.values()));ix['source_imports'].append({'collection':'official-relics-creator-identity-20261019','resolved_source_rows':18,'new_entries':len(newids),'remaining_pending':len(pending['rows'])})
assert len(newids)==18 and len(pending['rows'])==111 and ix['source_record_count']==2482 and len(entries)==2158
(D/'catalogue-index.json').write_text(json.dumps(ix,separators=(',',':'),ensure_ascii=False)+'\n')
for h in '0123456789abcdef':(D/('details-'+h+'.json')).write_text(json.dumps({k:v for k,v in details.items()if k.startswith(h)},separators=(',',':'),ensure_ascii=False)+'\n')
(D/'musthave-pending-identities.json').write_text(json.dumps(pending,indent=2)+'\n');report={'scope':'Official creator identity resolution; no native compatibility promotion','entries':len(entries),'source_records':ix['source_record_count'],'catalogued_favorites':sum(e['favorite']for e in entries.values()),'resolved_rows':18,'new_entries':18,'remaining_pending':len(pending['rows']),'all_previous_sources_preserved':True,'applied':applied};(D/'relics-family-import-verification.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items()if k!='applied'})
