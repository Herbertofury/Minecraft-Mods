from pathlib import Path
import urllib.request,json,hashlib
R=Path(__file__).resolve().parent;url='https://api.modrinth.com/v2/user/SSKirillSS/projects';req=urllib.request.Request(url,headers={'User-Agent':'Herbertofury/Minecraft-Mods-research/1.0 (https://github.com/Herbertofury/Minecraft-Mods)'})
with urllib.request.urlopen(req,timeout=45)as res:raw=res.read(10000000)
assert len(raw)<10000000;projects=json.loads(raw);safe=[{k:p.get(k)for k in ['id','slug','title','project_type','source_url','status','team','description','categories','additional_categories']}for p in projects];(R/'SSKirillSS-project-identities.json').write_text(json.dumps({'url':url,'checked_utc':'2026-10-19','response_sha256':hashlib.sha256(raw).hexdigest(),'scope':'Public creator-project identity only; no exact-release or native compatibility verification','projects':safe},indent=2)+'\n');print([(p['title'],p['slug'])for p in safe])
