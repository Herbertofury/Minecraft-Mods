"""Deterministic paired cache revision for this catalogue's index and detail shards."""
from pathlib import Path
import hashlib,re,argparse,json

def revision(files):
 h=hashlib.sha256()
 for name,data in sorted(files):h.update(name.encode());h.update(data)
 return h.hexdigest()[:16]
def rewrite(html,rev):
 if not re.fullmatch('[0-9a-f]{16}',rev):raise ValueError('Invalid revision')
 patterns=[r"(fetch\('catalogue-index\.json\?v=)[^']+(')",r"(fetch\('details-'\+key\+'\.json\?v=)[^']+(')"]
 out=html
 for pat in patterns:
  out,n=re.subn(pat,lambda m:m[1]+'catalogue-'+rev+m[2],out)
  if n!=1:raise ValueError('Expected exactly one supported request: '+pat)
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--docs',type=Path,required=True);p.add_argument('--check',action='store_true');a=p.parse_args();fs=[a.docs/'catalogue-index.json',*sorted(a.docs.glob('details-?.json'))]
 if len(fs)!=17:raise ValueError('Expected one index and sixteen detail shards')
 rev=revision([(f.name,f.read_bytes())for f in fs]);p=a.docs/'index.html';old=p.read_text();new=rewrite(old,rev)
 if a.check and old!=new:raise SystemExit('Stale catalogue cache revision')
 if not a.check and old!=new:p.write_text(new)
 print(json.dumps({'revision':rev,'changed':old!=new,'check_only':a.check,'data_files':len(fs)}))
