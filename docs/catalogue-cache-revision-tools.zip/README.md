# Catalogue cache revision helper

The public catalogue requests an index and sixteen detail shards. Publishing new data without changing their request revision can leave returning readers seeing an older catalogue. This helper derives one deterministic revision from all seventeen data files and updates both request sites together.

python refresh.py --docs /path/to/Minecraft-Mods/docs
python refresh.py --docs /path/to/Minecraft-Mods/docs --check
python -m unittest test_refresh

Publish the changed index.html alongside the data files. The check fails if the HTML revision is stale. Unexpected request syntax or a missing shard fails closed, so inspect the frontend rather than silently changing arbitrary text. Four tests cover order stability, changed data, paired idempotent edits and unsupported/duplicate request rejection. Live deployment and browser checks remain separate.

This is a publication freshness check, not a runtime compatibility or performance benchmark. It does not contact any account or service and does not install software.
