import unittest
from refresh import revision,rewrite
H="fetch('catalogue-index.json?v=old');fetch('details-'+key+'.json?v=old');"
class Tests(unittest.TestCase):
 def test_order(self):self.assertEqual(revision([('a',b'x'),('b',b'y')]),revision([('b',b'y'),('a',b'x')]))
 def test_data_change(self):self.assertNotEqual(revision([('a',b'x')]),revision([('a',b'y')]))
 def test_paired_idempotent(self):
  r=revision([('a',b'x')]);s=rewrite(H,r);self.assertEqual(s.count(r),2);self.assertEqual(rewrite(s,r),s)
 def test_fail_closed(self):
  for h in [H+H,H.replace('details-','other-')]:
   with self.assertRaises(ValueError):rewrite(h,'0'*16)
if __name__=='__main__':unittest.main()
